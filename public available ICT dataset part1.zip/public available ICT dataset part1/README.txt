This dataset contain sorts of industrial parts ICT images, only for research.
we are very pleased researchers use our ICT image dataset, and please refer our paper.

[1] Kuidong Huang, Zhixiang Li, Shaojie Tang, Yang Zeng, Wenguang Ye, Fuqiang Yang, A level-set method with the 3D multiplicative-additive model for CT volume data segmentation, Measurement, Volume 229, 2024, 114442.
https://doi.org/10.1016/j.measurement.2024.114442.